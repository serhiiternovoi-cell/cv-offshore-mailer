
export default function Privacy(){return(<main className="container py-12"><h1 className="text-3xl font-bold">Privacy Policy</h1><p className="mt-4 text-neutral-600">Describe how you handle user data, emails, and CV files. Mention no-storage policy and data retention limits.</p></main>);}


export default function Terms(){return(<main className="container py-12"><h1 className="text-3xl font-bold">Terms of Service</h1><p className="mt-4 text-neutral-600">Set out your service scope, pricing, refund policy, delivery timeframes, and limitations.</p></main>);}


export function Input(props:any){ return <input className="h-10 w-full rounded-xl border border-neutral-300 px-3 text-sm outline-none focus:ring-2 focus:ring-neutral-800/20" {...props}/> }
